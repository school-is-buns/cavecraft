// Future inventory module
