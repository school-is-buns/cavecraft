// Future block definitions module
